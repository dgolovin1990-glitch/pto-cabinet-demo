import json, sys
from pathlib import Path
from datetime import date
base=Path(sys.argv[1] if len(sys.argv)>1 else 'outputs')
d=json.loads((base/'data/Демо-ПТО.json').read_text(encoding='utf-8'))
start='2026-10-01';end='2026-10-31';a='2026-10-19'
s=[x for x in d['schemes'] if start<=x['plan']<=end]
r=[x for x in d['remarks'] if start<=x['plan']<=end and x['received']<=a]
j=[x for x in d['journals'] if start<=x['plan']<=end]
done=lambda x,k:bool(x[k]) and x[k]<=a
control={
'schemesPlan':len(s),'schemesFact':sum(done(x,'done') for x in s),
'schemesDue':sum(x['plan']<=a for x in s),'schemesDueFact':sum(x['plan']<=a and done(x,'done') for x in s),
'idLate':sum(x['idPlan']<a and not done(x,'sent') for x in s),'idSent':sum(done(x,'sent') for x in s),
'remarksTotal':len(r),'remarksWorked':sum(done(x,'worked') for x in r),'remarksClosed':sum(done(x,'closed') for x in r),
'remarksPending':sum(done(x,'worked') and not done(x,'closed') for x in r),
'remarksLate':sum(x['plan']<a and not done(x,'closed') for x in r),
'remarksCritical':sum(x['priority']=='Критичный' and not done(x,'closed') for x in r),
'journalsPlan':len(j),'journalsFact':sum(done(x,'done') for x in j),'journalsMissing':sum(x['plan']<a and not done(x,'done') for x in j),
'journalsDue':sum(x['plan']<=a for x in j),'journalsDueFact':sum(x['plan']<=a and done(x,'done') for x in j)
}
js=json.loads((base/'Проверки-ядра.json').read_text(encoding='utf-8'))['metrics']
for k,v in control.items():
    assert js[k]==v,(k,v,js[k])
for kind in ['schemes','remarks','journals']:
    assert len({x['id'] for x in d[kind]})==len(d[kind])
live_match=None
if len(sys.argv)>2:
    live=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
    for kind in ['schemes','remarks','journals']:
        assert d[kind]==live[kind],kind
    live_match={'schemes':96,'remarks':72,'journals':176}
result={'passed':True,'method':'Independent Python loops; optional browser Google Sheets JSON export comparison','date':'2026-10-19','metrics':control,'liveRowMatch':live_match}
(base/'Независимая-сверка.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS: 16 independent metrics'+(' and all 344 live rows match' if live_match else ''))
