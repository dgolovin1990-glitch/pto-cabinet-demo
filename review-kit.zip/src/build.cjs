const fs=require('fs'),path=require('path');
const dir=__dirname;let html=fs.readFileSync(path.join(dir,'template.html'),'utf8');
const css=fs.readFileSync(path.join(dir,'styles.css'),'utf8').replace('/*ARCHITECTURE*/',()=>fs.readFileSync(path.join(dir,'architecture.svg')).toString('base64'));
html=html.replace('/*STYLES*/',()=>css).replace('/*CORE*/',()=>fs.readFileSync(path.join(dir,'core.js'),'utf8')).replace('/*APP*/',()=>fs.readFileSync(path.join(dir,'app.js'),'utf8'));
if(process.argv.includes('--online'))html=html.replace('<body>','<body data-mode="online">');
const target=process.argv[2]||'outputs/Кабинет-ПТО.html';fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,html);console.log('HTML built: '+Buffer.byteLength(html)+' bytes');
