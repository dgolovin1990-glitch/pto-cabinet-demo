(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.PTO=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const DAY=86400000, VERSION=1, ASOF='2026-10-19';
const specs={
 schemes:{sheet:'ИД_Схемы',headers:['ID','Объект','Раздел','Исполнитель','Наименование','Начало','План_схемы','План_ИД','Схема_факт','Проверено','Подписано','Передано'],keys:['id','object','section','owner','title','start','plan','idPlan','done','checked','signed','sent'],dates:['start','plan','idPlan','done','checked','signed','sent'],required:['id','object','section','owner','title','start','plan','idPlan'],hint:'Одна строка = схема и её комплект ИД. Даты YYYY-MM-DD; фактические даты оставляйте пустыми до события.'},
 remarks:{sheet:'Замечания',headers:['ID','ID_схемы','Объект','Раздел','Исполнитель','Содержание','Получено','Срок','Отработано','Закрыто','Приоритет'],keys:['id','schemeId','object','section','owner','title','received','plan','worked','closed','priority'],dates:['received','plan','worked','closed'],required:['id','schemeId','object','section','owner','title','received','plan','priority'],hint:'Одна строка = замечание. «Отработано» — исправлено исполнителем; «Закрыто» — подтверждено принимающей стороной.'},
 journals:{sheet:'Журналы',headers:['ID','ID_журнала','Объект','Раздел','Исполнитель','Вид_журнала','План_записи','Факт_записи','Примечание'],keys:['id','journalId','object','section','owner','type','plan','done','title'],dates:['plan','done'],required:['id','journalId','object','section','owner','type','plan'],hint:'Одна строка = одна плановая запись журнала. Для нового рабочего дня добавьте строку с новым ID.'}
};
const stages=['Не начато','Подготовка','Проверка','Подписание','К передаче','Передано'];
const types=['ОЖР','Бетонные работы','Сварочные работы','Монтажные работы'];
function validDate(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s;}
function add(s,n){return new Date(Date.parse(s+'T00:00:00Z')+n*DAY).toISOString().slice(0,10);}
function diff(a,b){return Math.round((Date.parse(a+'T00:00:00Z')-Date.parse(b+'T00:00:00Z'))/DAY);}
function happened(d,asOf){return !!d&&d<=asOf;}
function hash(s){let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return (h>>>0).toString(16).padStart(8,'0');}
function random(seed){let x=parseInt(hash(seed),16)||1;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
function generate(seed='PTO-2026-01'){
 const r=random(seed),pick=a=>a[Math.floor(r()*a.length)],int=(a,b)=>a+Math.floor(r()*(b-a+1));
 const objects=['Квартал «Лунный Контур»','Центр «Бирюзовый Шпиль»','Комплекс «Северная Призма»','Парк «Янтарная Орбита»'];
 const owners=['Лира Тальвина','Орен Велисов','Мира Фаренцева','Ян Селмарин','Эна Ветрисова'];
 const sections=['КЖ','КМ','ОВ','ВК']; const schemes=[];
 for(let i=0;i<96;i++){
  const start=add('2026-09-20',int(0,37)),plan=add(start,int(5,11)),idPlan=add(plan,int(4,9));
  const x={id:'ИС-'+String(i+1).padStart(3,'0'),object:objects[i%4],section:sections[Math.floor(i/4)%4],owner:owners[i%5],title:pick(['Плита перекрытия','Узел примыкания','Трасса коммуникаций','Вертикальные отметки','Схема армирования'])+' · участок '+(i+1),start,plan,idPlan,done:'',checked:'',signed:'',sent:''};
  const candidate=add(plan,int(-3,6));if(candidate<=ASOF&&r()<.86)x.done=candidate;
  if(x.done){const c=add(x.done,int(1,3));if(c<=ASOF&&r()<.86)x.checked=c;}
  if(x.checked){const c=add(x.checked,int(1,4));if(c<=ASOF&&r()<.82)x.signed=c;}
  if(x.signed){const c=add(x.signed,int(0,2));if(c<=ASOF&&r()<.9)x.sent=c;}
  schemes.push(x);
 }
 const eligible=schemes.filter(x=>x.start<=add(ASOF,-3)),remarks=[];
 for(let i=0;i<72;i++){
  const s=pick(eligible),received=add(s.start,int(1,Math.max(1,Math.min(12,diff(ASOF,s.start))))),plan=add(received,int(3,8));
  const x={id:'ЗМ-'+String(i+1).padStart(3,'0'),schemeId:s.id,object:s.object,section:s.section,owner:s.owner,title:pick(['Уточнить привязку осей','Дополнить отметки','Исправить обозначение узла','Приложить лист согласования','Уточнить номер акта']),received,plan,worked:'',closed:'',priority:pick(['Обычный','Высокий','Критичный'])};
  const w=add(received,int(1,10));if(w<=ASOF&&r()<.76)x.worked=w;
  if(x.worked){const c=add(x.worked,int(1,4));if(c<=ASOF&&r()<.75)x.closed=c;}
  remarks.push(x);
 }
 const journals=[];let k=0;
 for(let o=0;o<4;o++)for(let t=0;t<2;t++)for(let day=1;day<=31;day++){
  const plan='2026-10-'+String(day).padStart(2,'0'),wd=new Date(plan+'T00:00:00Z').getUTCDay();if(wd===0||wd===6)continue;
  const x={id:'ЗП-'+String(++k).padStart(3,'0'),journalId:'ЖР-'+(o+1)+'-'+(t+1),object:objects[o],section:sections[o],owner:owners[(o+t)%5],type:t?types[1+o%3]:'ОЖР',plan,done:'',title:'Плановая запись за рабочую дату'};
  const c=add(plan,r()<.78?0:int(1,4));if(c<=ASOF&&r()<.86)x.done=c;journals.push(x);
 }
 return {version:VERSION,demo:true,seed:String(seed),asOf:ASOF,schemes,remarks,journals};
}
function validate(data){
 const errors=[];if(!data||typeof data!=='object')return ['Ожидается объект снимка'];
 if(data.demo!==true)errors.push('Снимок должен иметь demo: true («Демо-данные»)');
 if(data.version!==VERSION)errors.push('Неподдерживаемая версия снимка');
 if(!validDate(data.asOf))errors.push('Некорректная дата среза снимка');
 const ids={};
 for(const [kind,sp] of Object.entries(specs)){
  if(!Array.isArray(data[kind])){errors.push(sp.sheet+': отсутствует массив записей');continue;}
  if(data[kind].length>10000){errors.push(sp.sheet+': максимум 10 000 строк');continue;}
  ids[kind]=new Set();
  data[kind].forEach((x,i)=>{
   const loc=sp.sheet+', строка '+(i+4)+': ';
   if(!x||typeof x!=='object'||Array.isArray(x)){errors.push(loc+'ожидается запись');return;}
   for(const key of sp.keys){if(x[key]!=null&&typeof x[key]!=='string')errors.push(loc+key+' должен быть текстом/ISO-датой');}
   for(const key of sp.required)if(typeof x[key]!=='string'||!x[key].trim())errors.push(loc+'не заполнено '+sp.headers[sp.keys.indexOf(key)]);
   for(const key of sp.dates)if(x[key]&&!validDate(x[key]))errors.push(loc+'дата '+sp.headers[sp.keys.indexOf(key)]+' должна быть YYYY-MM-DD');
   if(ids[kind].has(x.id))errors.push(loc+'дубликат ID '+x.id);ids[kind].add(x.id);
   const chain=kind==='schemes'?['start','done','checked','signed','sent']:kind==='remarks'?['received','worked','closed']:[];
   for(let j=1;j<chain.length;j++){const a=x[chain[j-1]],b=x[chain[j]];if(b&&!a)errors.push(loc+'есть '+chain[j]+' без '+chain[j-1]);if(a&&b&&a>b)errors.push(loc+'нарушен порядок '+chain[j-1]+' → '+chain[j]);}
   if(kind==='schemes'&&(x.plan<x.start||x.idPlan<x.plan))errors.push(loc+'план схемы должен быть не раньше начала, план ИД — не раньше плана схемы');
   if(kind==='remarks'&&x.plan<x.received)errors.push(loc+'срок раньше получения');
   if(kind==='remarks'&&!['Обычный','Высокий','Критичный'].includes(x.priority))errors.push(loc+'неизвестный приоритет');
   if(kind==='journals'&&!types.includes(x.type))errors.push(loc+'неизвестный вид журнала');
   if(kind==='journals'&&x.done&&x.done<x.plan)errors.push(loc+'факт записи раньше рабочей даты');
  });
 }
 if(Array.isArray(data.schemes)&&Array.isArray(data.remarks)){
  const index=new Map(data.schemes.filter(x=>x&&typeof x==='object').map(x=>[x.id,x]));
  data.remarks.forEach((x,i)=>{if(!x||typeof x!=='object')return;const s=index.get(x.schemeId),loc='Замечания, строка '+(i+4)+': ';if(!s)errors.push(loc+'не найдена схема '+x.schemeId);else {if(s.object!==x.object||s.section!==x.section)errors.push(loc+'объект/раздел не совпадает со схемой');if(x.received<s.start)errors.push(loc+'получено раньше начала схемы');}});
 }
 if(Array.isArray(data.journals)){
  const seen=new Set(),reg=new Map();data.journals.forEach((x,i)=>{if(!x||typeof x!=='object')return;const key=x.journalId+'|'+x.plan,attrs=[x.object,x.section,x.type].join('|');if(seen.has(key))errors.push('Журналы, строка '+(i+4)+': повтор журнала за дату');seen.add(key);if(reg.has(x.journalId)&&reg.get(x.journalId)!==attrs)errors.push('Журналы, строка '+(i+4)+': ID журнала меняет объект/раздел/вид');reg.set(x.journalId,attrs);});
 }
 return errors;
}
function stage(x,a){if(happened(x.sent,a))return 5;if(happened(x.signed,a))return 4;if(happened(x.checked,a))return 3;if(happened(x.done,a))return 2;if(happened(x.start,a))return 1;return 0;}
function lateID(x,a){return x.idPlan<a&&!happened(x.sent,a);}
function deviation(x,a){return happened(x.sent,a)?diff(x.sent,x.idPlan):Math.max(0,diff(a,x.idPlan));}
function match(x,f){return (!f.object||x.object===f.object)&&(!f.owner||x.owner===f.owner)&&(!f.section||x.section===f.section)&&(!f.from||x.plan>=f.from)&&(!f.to||x.plan<=f.to);}
function select(data,f={}){const a=f.asOf||data.asOf;return {schemes:data.schemes.filter(x=>match(x,f)),remarks:data.remarks.filter(x=>match(x,f)&&x.received<=a),journals:data.journals.filter(x=>match(x,f))};}
const count=(xs,p)=>xs.filter(p).length;
const percent=(n,d)=>d?100*n/d:null;
function metrics(rows,a){
 const s=rows.schemes,r=rows.remarks,j=rows.journals,sd=s.filter(x=>x.plan<=a),jd=j.filter(x=>x.plan<=a);
 return {schemesPlan:s.length,schemesFact:count(s,x=>happened(x.done,a)),schemesDue:sd.length,schemesDueFact:count(sd,x=>happened(x.done,a)),schemesRate:percent(count(sd,x=>happened(x.done,a)),sd.length),idLate:count(s,x=>lateID(x,a)),idSent:count(s,x=>happened(x.sent,a)),stages:stages.map((_,i)=>count(s,x=>stage(x,a)===i)),remarksTotal:r.length,remarksWorked:count(r,x=>happened(x.worked,a)),remarksClosed:count(r,x=>happened(x.closed,a)),remarksPending:count(r,x=>happened(x.worked,a)&&!happened(x.closed,a)),remarksLate:count(r,x=>x.plan<a&&!happened(x.closed,a)),remarksCritical:count(r,x=>x.priority==='Критичный'&&!happened(x.closed,a)),journalsPlan:j.length,journalsFact:count(j,x=>happened(x.done,a)),journalsDue:jd.length,journalsDueFact:count(jd,x=>happened(x.done,a)),journalsRate:percent(count(jd,x=>happened(x.done,a)),jd.length),journalsMissing:count(j,x=>x.plan<a&&!happened(x.done,a)),ojr:journalMetric(j.filter(x=>x.type==='ОЖР'),a),special:journalMetric(j.filter(x=>x.type!=='ОЖР'),a)};
}
function journalMetric(j,a){return {plan:j.length,fact:count(j,x=>happened(x.done,a)),missing:count(j,x=>x.plan<a&&!happened(x.done,a))};}
function monday(s){const d=new Date(s+'T00:00:00Z').getUTCDay();return add(s,-((d+6)%7));}
function weekly(s,a){const m=new Map();s.forEach(x=>{const w=monday(x.plan);if(!m.has(w))m.set(w,{week:w,plan:0,fact:0});m.get(w).plan++;if(happened(x.done,a))m.get(w).fact++;});return [...m.values()].sort((a,b)=>a.week.localeCompare(b.week));}
function decisions(m){const out=[];
 if(m.idLate)out.push({kind:'schemes',filter:'late',tone:'danger',title:'Разобрать просрочку передачи ИД',body:m.idLate+' комплектов ожидают передачи после планового срока. Уточните блокировку проверки и подписания.',count:m.idLate});
 if(m.remarksCritical)out.push({kind:'remarks',filter:'critical',tone:'danger',title:'Проверить критичные замечания',body:m.remarksCritical+' критичных замечаний без подтверждённого закрытия. Назначьте приоритет и контрольный срок.',count:m.remarksCritical});
 if(m.journalsMissing)out.push({kind:'journals',filter:'late',tone:'warn',title:'Восстановить записи журналов',body:m.journalsMissing+' плановых записей отсутствуют за прошедшие даты. Проверьте конкретные журналы и исполнителей.',count:m.journalsMissing});
 if(m.remarksPending)out.push({kind:'remarks',filter:'pending',tone:'warn',title:'Получить подтверждение исправлений',body:m.remarksPending+' замечаний отработаны, но ещё не приняты. Согласуйте проверку с принимающей стороной.',count:m.remarksPending});
 if(m.schemesRate!==null&&m.schemesRate<85)out.push({kind:'schemes',filter:'unfinished',tone:'warn',title:'Сверить загрузку подготовки схем',body:'Выполнено '+Math.round(m.schemesRate)+'% плана к срезу. Проверьте ресурс и очередь задач; порог 85% принят для демо.',count:m.schemesDue-m.schemesDueFact});
 return out;
}
function rowMatch(kind,x,filter,a){if(!filter)return true;
 if(kind==='schemes'){if(filter==='late')return lateID(x,a);if(filter==='unfinished')return x.plan<=a&&!happened(x.done,a);if(filter.startsWith('stage:'))return stage(x,a)===Number(filter.split(':')[1]);if(filter==='done')return happened(x.done,a);}
 if(kind==='remarks'){if(filter==='late')return x.plan<a&&!happened(x.closed,a);if(filter==='pending')return happened(x.worked,a)&&!happened(x.closed,a);if(filter==='critical')return x.priority==='Критичный'&&!happened(x.closed,a);if(filter==='done')return happened(x.worked,a);if(filter==='closed')return happened(x.closed,a);}
 if(kind==='journals'){if(filter==='late')return x.plan<a&&!happened(x.done,a);if(filter==='done')return happened(x.done,a);if(filter==='ojr')return x.type==='ОЖР';if(filter==='special')return x.type!=='ОЖР';}return false;
}
function parseCSV(text){
 if(typeof text!=='string'||text.length>12000000)throw Error('CSV пуст или больше 12 МБ');text=text.replace(/^\uFEFF/,'');
 const rows=[];let row=[],cell='',quoted=false,closed=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(quoted){if(c==='"'){if(text[i+1]==='"'){cell+='"';i++;}else {quoted=false;closed=true;}}else cell+=c;}
 else if(c===','||c==='\n'||c==='\r'){row.push(cell);cell='';closed=false;if(c!==','){rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}}
 else if(c==='"'){if(cell||closed)throw Error('CSV: кавычка внутри неэкранированного поля');quoted=true;}
 else {if(closed)throw Error('CSV: символ после закрывающей кавычки');cell+=c;}}
 if(quoted)throw Error('CSV: незакрытая кавычка');if(cell||row.length||closed){row.push(cell);rows.push(row);}return rows;
}
function csvCell(v){let s=String(v??'');if(/^[\s]*[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
function toCSV(kind,rows,banner=true){const sp=specs[kind],out=banner?[['Демо-данные'],[sp.hint],sp.headers]:[sp.headers];for(const x of rows)out.push(sp.keys.map(k=>x[k]||''));return '\uFEFF'+out.map(r=>r.map(csvCell).join(',')).join('\r\n');}
function fromCSV(kind,text){const rows=parseCSV(text),sp=specs[kind];if(rows[0]?.[0]?.trim()!=='Демо-данные')throw Error(sp.sheet+': строка 1 должна содержать «Демо-данные»');const header=rows[2];if(!header||sp.headers.some((h,i)=>header[i]!==h))throw Error(sp.sheet+': заголовки строки 3 не соответствуют шаблону');return rows.slice(3).filter(r=>r.some(v=>v.trim())).map((r,i)=>{if(r.length>sp.keys.length&&r.slice(sp.keys.length).some(v=>v.trim()))throw Error(sp.sheet+', строка '+(i+4)+': лишние столбцы');return Object.fromEntries(sp.keys.map((k,j)=>[k,(r[j]||'').trim()]));});}
function makeDataset(parts,seed='импорт'){return {version:VERSION,demo:true,seed,asOf:ASOF,...parts};}
function selfTest(){const d=generate(),e=validate(d),m=metrics(select(d,{from:'2026-10-01',to:'2026-10-31',asOf:ASOF}),ASOF);return [{name:'Структура и связи',ok:e.length===0,detail:e[0]||'Все строки корректны'},{name:'Воспроизводимость seed',ok:JSON.stringify(d)===JSON.stringify(generate()),detail:hash(JSON.stringify(d))},{name:'Сумма этапов',ok:m.stages.reduce((a,b)=>a+b,0)===m.schemesPlan,detail:'Этапы не дублируют схемы'},{name:'Отработка / закрытие',ok:m.remarksClosed<=m.remarksWorked&&m.remarksWorked<=m.remarksTotal,detail:'Закрытые ≤ отработанные ≤ полученные'},{name:'Факт в границах плана',ok:m.schemesFact<=m.schemesPlan&&m.journalsFact<=m.journalsPlan,detail:'Количество не превышает плановую совокупность'},{name:'Нулевой знаменатель',ok:percent(0,0)===null,detail:'Показывается «н/д»'},{name:'CSV round-trip',ok:JSON.stringify(fromCSV('schemes',toCSV('schemes',d.schemes)))===JSON.stringify(d.schemes),detail:'Кавычки и даты сохранены'}];}
return {VERSION,ASOF,specs,stages,types,validDate,add,diff,happened,hash,generate,validate,stage,lateID,deviation,select,metrics,weekly,decisions,rowMatch,parseCSV,toCSV,fromCSV,makeDataset,selfTest,percent};
});
